﻿namespace WebApplication3 {
    
    
    public partial class DataSet2 {
    }
}
