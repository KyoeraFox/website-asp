﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        string connection = ConfigurationManager.ConnectionStrings["DBCONNECT"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack){
                ReportViewer1.ProcessingMode = ProcessingMode.Local;
                ReportViewer1.SizeToReportContent = true;
                ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report2.rdlc");
                DataSet1 ds = GetData("select * from TB_NATION");
                ReportViewer2.SizeToReportContent = true;
                ReportDataSource datasource = new ReportDataSource("DataSet1", ds.Tables[0]);
                ReportViewer1.LocalReport.DataSources.Clear();
                ReportViewer1.LocalReport.DataSources.Add(datasource);
            }
        }

        private DataSet1 GetData(string query)
        {
            string conString = ConfigurationManager.ConnectionStrings["DBCONNECT"].ConnectionString;
            SqlCommand cmd = new SqlCommand(query);
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;

                    sda.SelectCommand = cmd;
                    using (DataSet1 ds = new DataSet1())
                    {
                        sda.Fill(ds, "DataTable1");
                        return ds;
                    }
                }
            }
        }

        public void load_report(string parameter)
        {

            ReportViewer2.ProcessingMode = ProcessingMode.Local;
            ReportViewer2.SizeToReportContent = true;
            ReportViewer2.LocalReport.ReportPath = Server.MapPath("reportDts.rdlc");

            ReportParameter parameter1 = new ReportParameter("value", parameter);
            ReportParameter parameter2 = new ReportParameter("content", get_data(parameter));
            ReportParameter parameter3 = new ReportParameter("count", count().ToString());
            ReportViewer2.LocalReport.SetParameters(parameter1);
            ReportViewer2.LocalReport.SetParameters(parameter2);
            ReportViewer2.LocalReport.SetParameters(parameter3);
            newDts m = new newDts();

            string sql = "SELECT * FROM TB_NATION  where ID ='" + parameter + "'";
            System.Data.SqlClient.SqlConnection con = new SqlConnection(connection);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            da.Fill(m, m.Tables[0].TableName);

            ReportDataSource rds = new ReportDataSource("DataSet1", m.Tables[0]);

            this.ReportViewer2.LocalReport.DataSources.Clear();
            this.ReportViewer2.LocalReport.DataSources.Add(rds);
            this.ReportViewer2.LocalReport.Refresh();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string id = TextBox1.Text;
            load_report(id);
            Session["test_id"] = id;
            //Response.Redirect("WebForm6.aspx");
        }

        public string get_data(string para)
        {
            string nation = "select nation from TB_NATION  where id = " + para + "";
            SqlConnection con = new SqlConnection(connection);
            SqlDataAdapter data = new SqlDataAdapter(nation, con);
            DataTable tb = new DataTable();
            data.Fill(tb);
            if (tb.Rows.Count > 0)
            {
                return tb.Rows[0][0].ToString();
            }
            else
            {
                return "0";
            }
        }

        public int count()
        {
            string nation = "select count(*) from TB_NATION";
            SqlConnection con = new SqlConnection(connection);
            SqlDataAdapter data = new SqlDataAdapter(nation, con);
            DataTable tb = new DataTable();
            data.Fill(tb);
            int count = Int32.Parse(tb.Rows[0][0].ToString());
            return count;
        }
    }
}