﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ReportViewer2.ProcessingMode = ProcessingMode.Local;
                ReportViewer2.LocalReport.ReportPath = Server.MapPath("~/Report2.rdlc");
                DataSet1 ds = GetData("select * from TB_NATION");
                ReportDataSource datasource = new ReportDataSource("DataSet1", ds.Tables[0]);
                ReportViewer2.LocalReport.DataSources.Clear();
                ReportViewer2.LocalReport.DataSources.Add(datasource);
            }
        }


        private DataSet1 GetData(string query)
        {
            string conString = ConfigurationManager.ConnectionStrings["DBCONNECT"].ConnectionString;
            SqlCommand cmd = new SqlCommand(query);
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;

                    sda.SelectCommand = cmd;
                    using (DataSet1 ds = new DataSet1())
                    {
                        sda.Fill(ds, "DataTable1");
                        return ds;
                    }
                }
            }
        }


        public void parameter()
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Warning[] warnings;
            string[] streamids;
            string mimeType;
            string encoding;
            string extension;
            string filename;

            byte[] bytes = ReportViewer2.LocalReport.Render(
               "Excel", null, out mimeType, out encoding,
                out extension,
               out streamids, out warnings);

            filename = string.Format("{0}.{1}", "EXPORT2", "xls");
            Response.ClearHeaders();
            Response.Clear();
            Response.AddHeader("Content-Disposition", "attachment;filename=" + filename);
            Response.ContentType = mimeType;
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.End();
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            //Warning[] warnings;
            //string[] streams;
            //string mimeType;
            //string encoding;
            //string extension;

            //byte[] bytes = reportViewer1.LocalReport.Render(“Word”, null, out mimeType, out encoding, out extension, out streams, out warnings);
            //HttpContext.Current.Response.Buffer = true;
            //HttpContext.Current.Response.Clear();
            //HttpContext.Current.Response.ContentType = mimeType;
            //HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=ExportedReport." + fileNameExtension);
            //HttpContext.Current.Response.BinaryWrite(exportBytes);
            //HttpContext.Current.Response.Flush();
            //HttpContext.Current.Response.End();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearch.Text;
            if (search == "")
            {
                return;
            }
            else {
                ReportViewer2.ProcessingMode = ProcessingMode.Local;
                ReportViewer2.LocalReport.ReportPath = Server.MapPath("~/Report2.rdlc");
                DataSet1 dsSearch = GetData("select * from TB_NATION where NATION like '%" + search + "%' or cast(id as nvarchar(100))  = '" + search + "'");
                ReportDataSource datasource = new ReportDataSource("DataSet1", dsSearch.Tables[0]);
                ReportViewer2.LocalReport.DataSources.Clear();
                ReportViewer2.LocalReport.DataSources.Add(datasource);
                if (dsSearch.Tables[0].Rows.Count.ToString() == "0")
                {
                    lblThongbao.Text = "không có kết quả nào được tìm thấy";
                }
                else {
                    lblThongbao.Text = "có " + dsSearch.Tables[0].Rows.Count.ToString() + " kết quả được tìm thấy ";
                }
                
            }
            
        }
    }
}