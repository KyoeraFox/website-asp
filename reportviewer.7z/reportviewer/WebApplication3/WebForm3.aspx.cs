﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using WebApplication3.DataSet2TableAdapters;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace WebApplication3
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        string connection = ConfigurationManager.ConnectionStrings["DBCONNECT"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ReportViewer1.ProcessingMode = ProcessingMode.Local;
                DataSet2TableAdapters.SELECT_CITYTableAdapter ta = new DataSet2TableAdapters.SELECT_CITYTableAdapter();
                DataSet2.SELECT_CITYDataTable dt = new DataSet2.SELECT_CITYDataTable();
                ta.Fill(dt);
                ReportDataSource rds = new ReportDataSource();
                rds.Name = "DataSet1";
                rds.Value = dt;

                ReportViewer1.LocalReport.DataSources.Clear();
                ReportViewer1.LocalReport.ReportPath = "Report3.rdlc";
                ReportViewer1.LocalReport.DataSources.Add(rds);
                ReportViewer1.ServerReport.Refresh();
                Label1.Text = dt.Rows.Count.ToString();
            }
        }

        public void load_report(string parameter)
        {

            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.SizeToReportContent = true;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("Report3.rdlc");

            ReportParameter parameter1 = new ReportParameter("value", parameter);
            ReportViewer1.LocalReport.SetParameters(parameter1);
            DataSet2 m = new DataSet2();
            string sql = "SELECT * FROM TB_NATION  where id =" + parameter + "";
            System.Data.SqlClient.SqlConnection con = new SqlConnection(connection);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            da.Fill(m, m.Tables[0].TableName);
            ReportDataSource rds = new ReportDataSource("DataSet1", m.Tables[0].ToString());

            this.ReportViewer1.LocalReport.DataSources.Clear();
            this.ReportViewer1.LocalReport.DataSources.Add(rds);
            this.ReportViewer1.LocalReport.Refresh();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //ReportViewer1.ProcessingMode = ProcessingMode.Local;
            //DataSet2TableAdapters.SELECT_CITYTableAdapter ta = new DataSet2TableAdapters.SELECT_CITYTableAdapter();
            //DataSet2.SELECT_CITYDataTable dt = new DataSet2.SELECT_CITYDataTable();
            //ta.Fill(dt);
            //DataSet2 ds = new DataSet2();
            //ReportDataSource rds = new ReportDataSource();
            //rds.Name = "DataSet1";
            //rds.Value = dt;

            //ReportParameter rp = new ReportParameter("value", TextBox1.Text.ToString());

            //ReportViewer1.LocalReport.DataSources.Clear();
            //ReportViewer1.LocalReport.ReportPath = "ReportPara.rdlc";
            //ReportViewer1.LocalReport.SetParameters(new ReportParameter[] { rp });
            //ReportViewer1.LocalReport.DataSources.Add(rds);
            //ReportViewer1.LocalReport.Refresh();

            string id = TextBox1.Text;
            load_report(id);
        }
    }
}