﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.Reporting.WebForms;
using System.Net.Mail;
using System.Net;
using System.Net.Sockets;

namespace WebApplication3
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        string connection = ConfigurationManager.ConnectionStrings["DBCONNECT"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        

        public void load(string parameter) {
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.SizeToReportContent = true;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("reportDts.rdlc");

            ReportParameter parameter1 = new ReportParameter("value", parameter);
            ReportParameter parameter2 = new ReportParameter("content", get_data(parameter));
            ReportParameter parameter3 = new ReportParameter("count", count().ToString());
            ReportViewer1.LocalReport.SetParameters(new ReportParameter[] {parameter1, parameter2, parameter3});
            newDts m = new newDts();

            string sql = "SELECT * FROM TB_NATION  where ID ='" + parameter + "'";
            System.Data.SqlClient.SqlConnection con = new SqlConnection(connection);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            da.Fill(m, m.Tables[0].TableName);

            ReportDataSource rds = new ReportDataSource("DataSet1", m.Tables[0]);

            this.ReportViewer1.LocalReport.DataSources.Clear();
            this.ReportViewer1.LocalReport.DataSources.Add(rds);
            this.ReportViewer1.LocalReport.Refresh();
        }
        
        public string get_data(string para)
        {
            string nation = "select nation from TB_NATION  where id = " + para + "";
            SqlConnection con = new SqlConnection(connection);
            SqlDataAdapter data = new SqlDataAdapter(nation, con);
            DataTable tb = new DataTable();
            data.Fill(tb);
            if (tb.Rows.Count > 0)
            {
                return tb.Rows[0][0].ToString();
            }
            else
            {
                return "0";
            }
        }

        public int count()
        {
            string nation = "select count(*) from TB_NATION";
            SqlConnection con = new SqlConnection(connection);
            SqlDataAdapter data = new SqlDataAdapter(nation, con);
            DataTable tb = new DataTable();
            data.Fill(tb);
            int count = Int32.Parse(tb.Rows[0][0].ToString());
            return count;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string id = Session["test_id"].ToString();
            load(id);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //string Host = "Host IP of SMTP";
            //int Port = 25;

            //MailMessage mail = new MailMessage();

            //string to = TextBox3.Text;
            //string from = TextBox2.Text;
            //string body = TextBox1.Text;
            //string subject = TextBox4.Text;

            //MailMessage message = new MailMessage(from, to, subject, body);
            //message.IsBodyHtml = true;


            //SmtpClient client = new SmtpClient(Host, Port);
            //client.DeliveryMethod = SmtpDeliveryMethod.Network;
            //client.Send(message);

            ////////////////////////////////////////////////////////////////////////////////////
            //SmtpClient smtpClient = new SmtpClient("mail.MyWebsiteDomainName.com", 25);

            //smtpClient.Credentials = new System.Net.NetworkCredential("info@MyWebsiteDomainName.com", "myIDPassword");
            //smtpClient.UseDefaultCredentials = true;
            //smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            //smtpClient.EnableSsl = true;
            //MailMessage mail = new MailMessage();

            ////Setting From , To and CC
            //mail.From = new MailAddress("info@MyWebsiteDomainName", "MyWeb Site");
            //mail.To.Add(new MailAddress("info@MyWebsiteDomainName"));
            //mail.CC.Add(new MailAddress("MyEmailID@gmail.com"));

            //smtpClient.Send(mail);
        }


    }
}