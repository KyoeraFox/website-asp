﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Configuration;

namespace WebApplication2
{
    public partial class PROC : System.Web.UI.Page
    {
        string connect = WebConfigurationManager.ConnectionStrings["DBCONNECT"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
             if (e.CommandName == "Delete")
             {
                 Int16 index = Convert.ToInt16(e.CommandArgument);
                 string name = GridView1.Rows[index].Cells[1].Text.ToString();
                 MyDataDataContext db = new MyDataDataContext();
                 db.DEL_TB_PRODUCT(name);
             }
        }

           
   

        //protected void GridView1_RowCommand1(object sender, GridViewCommandEventArgs e)
        //{
        //    if (e.CommandName == "Delete")
        //    {
        //        //int index = Int32.Parse(e.CommandArgument.ToString());
        //        //string name = GridView1.Rows[index].Cells[1].Text.ToString();
        //        //MyDataDataContext db = new MyDataDataContext();
        //        //db.DEL_TB_PRODUCT(name);
        //        //load();

        //        Response.Write("<script>alert('aaaaaaaaaaaaaa')</script>");
        //    }
        //}

     

       

      
    }
}