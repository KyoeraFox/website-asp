﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;

namespace WebApplication4
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = new HttpCookie("CultureInfo_lang");
            cookie.Value = DropDownList1.SelectedValue;
            Response.Cookies.Add(cookie);

            if (DropDownList1.SelectedValue == "1")
            {
                cookie.Value = "en";
                Response.SetCookie(cookie);
            }
            else if (DropDownList1.SelectedValue == "2")
            {

                cookie.Value = "vi";
                Response.SetCookie(cookie);
            }
            Server.Transfer(Request.Path);
        }
    }
}