﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;

namespace WebApplication6
{
    public partial class comment : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["DBCONNECT"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            page_load();
            if(!IsPostBack){
                Response.Write("<script>alert('vui lòng nhtest');</script>");
            }
        }

        public void page_load() {
            string sql = "select * from TB_comment";
            SqlConnection con = new SqlConnection(conn);
            SqlDataAdapter data = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            data.Fill(dt);
            dtlComment.DataSource = dt;
            dtlComment.DataBind();
        }

        protected void btnDangbai_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string mess = textaraMess.Value.ToString();
            if (mess.Length > 50)
            {
                if (check_mess(name, mess) == true)
                {
                    insert_comment(name, mess);
                    page_load();
                }
                else {
                    Response.Write("<script>alert('vui lòng nhập nội dung khác');</script>");
                    return;
                }
                
            }
            else {
                Response.Write("<script>alert('vui lòng nhập nội dung dài hơn 50 kí tự');</script>");
            }
        }

        public bool check_mess(string name, string mess) {
            string sql = "select * from TB_comment where name = N'"+name+"' and mess = N'"+mess+"'";
            SqlConnection con = new SqlConnection(conn);
            SqlDataAdapter data = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            data.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return false;
            }
            else {
                return true;
            }
        }

        public void insert_comment(string name, string mess) {
            string sql = "insert into TB_comment values (N'"+name+"', N'"+mess+"')";
            SqlConnection con = new SqlConnection(conn);
            SqlCommand cm = new SqlCommand(sql, con);
            con.Open();
            cm.ExecuteNonQuery();
            con.Close();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            FileInfo file = new FileInfo("Z:/ITDB/ws/ws_comment/WebApplication6/file/website.xlsx");
            if (file.Exists)
            {
                Response.Clear();
                Response.ClearHeaders();
                Response.ClearContent();
                Response.AddHeader("content-disposition", "attachment; filename=" + "website.xlsx");
                Response.AddHeader("Content-Type", "application/Excel");
                Response.ContentType = "application/vnd.xls";
                Response.AddHeader("Content-Length", file.Length.ToString());
                Response.WriteFile(file.FullName);
                Response.End();
            }
            else
            {
                Response.Write("This file does not exist.");
            }
        }

       
    }
}